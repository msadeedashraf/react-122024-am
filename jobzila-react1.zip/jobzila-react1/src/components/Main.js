function Main() {
  return (
    <main>
      <section id="hero">
        <section id="hero-section">
          <h2>Welcome to JobZila</h2>
          <p class="vision-statement">
            Our Vision: Lorem ipsum dolor sit amet, consectetur adipiscing elit.
            Quisque in odio ac risus vestibulum tincidunt vel et eros. Integer
            vulputate turpis eget accumsan rhoncus. Etiam vitae risus in sem
            blandit ullamcorper et nec tortor. Fusce id commodo felis, id
            dapibus justo. Proin faucibus, enim id sagittis tincidunt, metus
            justo iaculis libero, non hendrerit est ipsum sit amet metus.
          </p>
        </section>
      </section>
    </main>
  );
}

export default Main;
